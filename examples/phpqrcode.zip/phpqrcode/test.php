<?php
include 'phpqrcode.php';
$text = 'http://m.ci123.com/user/login/qrconfirm?uuid=234234234324324';
$png = 'temp/test.png';
QRcode::png($text, false, 'Q', 7, 4, 1);
?>
