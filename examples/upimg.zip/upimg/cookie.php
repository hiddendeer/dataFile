<?php
/// PHP版本，获取用户登录COOKIE信息函数
define('PRIVATE_KEY', 'ffb6991624af0df4fb8edfefc2b0b4c2');
function getUserCookie() {
	$cookie = $_COOKIE['ci123'];
	$decodeed_cookie = base64_decode($cookie);
	list($A, $C) = split(';', $decodeed_cookie);
	if( md5($A.';'.PRIVATE_KEY) != $C) {
		return false;
	}
	$tmp = explode(',', $A);
	$data = array(
		'username'	=>	$tmp[0],
		'nickname'	=>	$tmp[1],
		'user_id'	=>	$tmp[2],
		'area'		=>	$tmp[3],
		'time'		=>	$tmp[4],
		'jointime'	=>	$tmp[5]
	);
	return $data;
}

/// 使用示例
$user = getUserCookie();
if(!empty($user)) {
	var_dump($user);
	echo "<br>\n";
	$jointime = $user['jointime']; // 用户的注册时间, UNIX时间戳格式，形如 1294717950
	echo "注册时间（原格式） :".$jointime;
	echo "<br>\n";
	$jointime_str = date('Y-m-d H:i:s', $jointime); // 转化为字符串格式，形如 2010-10-18
	echo "注册时间（字符串格式） :".$jointime_str;
	echo "<br>\n";
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>使用示例</title>
</head>

<body>
bhugbuygtyfyfty
<?php echo date('y-m-d H:i:s');?>
<script language="javascript" type="text/javascript" src="http://user.ci123.com/js/auth.js"></script>
<script language="javascript">
var ciuser = getUserInfo();
if(ciuser && ciuser.user_id != undefined) {
	// 返回的数据是数组对象格式
	alert(ciuser.toString());
	
	// 调用各项信息
	alert(ciuser.username); // 用户名
	alert(ciuser.nickname); // 用户昵称
	alert(ciuser.user_id); // 用户ID
	alert(ciuser.area); // 
	alert(ciuser.time); // 登陆时间，UNIX时间戳格式
	alert(ciuser.jointime); // 注册时间，UNIX时间戳格式
	
	// 注册时间转换格式示例
	alert('注册时间（原格式）：'+ciuser.jointime);
	var dt = new Date(ciuser.jointime*1000).toLocaleString();
	alert('注册时间（本地字符串格式）：'+dt);
}
</script>
</body>
</html>