<?php
/**
 * @abstract 处理提交
 */

// 验证提交方式，只支持post方法
if ($_SERVER['REQUEST_METHOD'] != 'POST') {
	exit;
}

// 处理ajax提交
if ($_POST) {
	// 获取用户信息
//	$user = getUserCookie();
	$userid = $user['user_id'];
//	if (!$userid) {
//		exit('登陆后才能操作');
//	}
	// 接收数据
	$avatar = trim($_POST['avatar']);
	if (!$avatar) {
		exit('请上传头像');
	}
	// 处理数据
	$data = array(
		'avatar' => $avatar
	);
	require_once 'class_xmlrpc.php';
	$rpc_pkey = 'Wy2o4gVlvPduJhjF2h5BERkBauM2VCim';
	$xmlrpc_client = new xmlrpc_client('http://user.ci123.com/rpc/muserService.php', 'user');
	$result = $xmlrpc_client->call('updateById', $rpc_pkey, $userid, $data);
	if (!$result) {
		exit('处理失败，错误号001');
	}
	exit('ok');
}

define('PRIVATE_KEY', 'ffb6991624af0df4fb8edfefc2b0b4c2');
function getUserCookie() {
	$cookie = $_COOKIE['ci123'];
	$decodeed_cookie = base64_decode($cookie);
	list($A, $C) = split(';', $decodeed_cookie);
	if( md5($A.';'.PRIVATE_KEY) != $C) {
		return false;
	}
	$tmp = explode(',', $A);
	$data = array(
		'username'	=>	$tmp[0],
		'nickname'	=>	$tmp[1],
		'user_id'	=>	$tmp[2],
		'area'		=>	$tmp[3],
		'time'		=>	$tmp[4],
		'jointime'	=>	$tmp[5]
	);
	return $data;
}
?>