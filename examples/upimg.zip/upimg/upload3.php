<?php
/**
 * @abstract 处理提交
 */

if ($_FILES['img']) {
	$img = $_FILES['img'];
	if ($img['size'] < 0) {
		echo "<script>parent.upimgCallback(0, '图片无效');</script>";
		exit;
	}
	$img_info = getimagesize($img['tmp_name']);
	if (!in_array($img_info[2], array(1,2,3))) {
		echo "<script>parent.upimgCallback(0, '图片格式不支持');</script>";
		exit;
	}
	$root = dirname(__FILE__);
	$dir = date('Ymd');
	if (!file_exists($root.'/'.$dir)) {
		@mkdir($root.'/'.$dir, 0775);
	}
	$path = $dir.'/'.md5(uniqid().mt_rand()).'.jpg';
	$file = $root.'/'.$path;
	if (!move_uploaded_file($img['tmp_name'], $file)) {
		echo "<script>parent.upimgCallback(0, '上传失败，代码001');</script>";
		exit;
	}
	$url = $path;
	echo "<script>parent.upimgCallback(1, '{$url}');</script>";
	exit;
}
?>