<?php
/**
 * 首页
 */

require_once __DIR__.'/inc/global.php';

$ip = getIp();
echo $ip;

$db = new Mysqls();
print_r($db);

