<?php
define('PATH_ROOT', dirname(__DIR__));

require_once PATH_ROOT.'/inc/function.php';
require_once PATH_ROOT.'/inc/mysqlClass.php';
