<?php
/**
 * @abstract 函数
 */

function getIp(){
	$ip = '';
	if ($_SERVER['HTTP_X_FORWARDED_FOR']) {
		$ips = explode(', ', $_SERVER['HTTP_X_FORWARDED_FOR']);
		foreach ($ips as $v) {
			$v = trim($v);
			if(!preg_match('/^(10|172\.16|192\.168|127\.0)\./', $v)) {
				if (strtolower($v) != 'unknown') {
					$ip = $v;
					break;
				}
			}
		}
	} elseif ($_SERVER['HTTP_CLIENT_IP']) {
		$ip = $_SERVER['HTTP_CLIENT_IP'];
	} else {
		$ip = $_SERVER['REMOTE_ADDR'];
	}
	if (!preg_match('/[\d\.]{7,15}/', $ip)) {
		$ip = '';
	} elseif (preg_match('/^(10|172\.16|192\.168|127\.0)\./', $ip)) {
		$ip = '';
	}
	return $ip;
}

function ajaxCallback($status, $message = '', $data = array()) {
	$return = array(
		'status' => strval($status),//状态 成功返回0 失败返回其他数字
		'message' => strval($message),//信息，失败时包含说明
		'data' => $data,//数据，成功时返回的数据
	);
	header('Content-type: text/html; charset=utf-8');
	echo json_encode($return);
	exit;
}
