<?php
/**
 * @abstract php邮件类示例
 */
ini_set('display_errors', 'off');
error_reporting(0);

date_default_timezone_set("Asia/Shanghai");

set_time_limit(0);

include_once(dirname(__FILE__).'/class.phpmailer.php');
include_once(dirname(__FILE__).'/class.smtp.php');

// 示例
$mailto = 'wangwei@corp-ci.com'; // 收件人
$mailcc = array('wangwei@corp-ci.com','chenyong@corp-ci.com'); // 抄送
$subject = 'test'; // 标题
$content = 'test'; // 正文，支持html
$attachments = array(
	'./a.txt',
	'./b.txt'
); // 附件，可选
$success = sendEmail($mailto, $mailcc, $subject, $content, $attachments);
if ($success) {
	echo 'ok';
}

// send email 注意{}中的内容是需要你自己手动替换的 自己去163申请个邮箱，使用163的邮箱服务器
function sendEmail($to, $cc = array(), $subject = "", $body = "", $attachments = array()) {
	$mail = new PHPMailer();
	$mail->CharSet = "UTF-8";
	$mail->IsSMTP();
	$mail->SMTPDebug = 1;
	$mail->SMTPAuth = true;
	$mail->SMTPSecure = "ssl";
	$mail->Host = "smtp.163.com";
	$mail->Port = 465;
	$mail->Username = "{你的163邮箱帐号}";
	$mail->Password = "{你的163邮箱密码}";
	$mail->SetFrom('{你的163邮箱帐号}@163.com', '{昵称}');
	$mail->AddReplyTo("{你的163邮箱帐号}@163.com", "{昵称}");
	$body = eregi_replace("[\]",'',$body);
	if (is_string($to)) {
		$to = array($to);
	}
	foreach ($to as $v) {
		$mail->AddAddress($v);
	}
	$mail->Subject  = $subject;
	$mail->AltBody  = "{提示}";
	$mail->MsgHTML($body);
	if (sizeof($attachments)) {
		foreach($attachments as $v) {
			$mail->AddAttachment($v);
		}
	}
	if(!$mail->Send()) {
		$success = false;
		echo "\nMailer Error: " . $mail->ErrorInfo . "\n";
	} else {
		$success = true;
	}
	$mail->ClearAllRecipients();
	return $success;
}
?>