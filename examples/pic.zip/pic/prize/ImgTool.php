<?php
/**
 * image
 *
 * @author chenyong <chenyong@sc-edu.com>
 * @version 2.0
 * @date 2017-02-24
 */

class ImgTool
{
    /**
     * 生成文字图片
     *
     * @param string 目标图路径，为空则返回资源对象
     * @param string 字体路径
     * @param string 文字
     * @param int 尺寸
     * @param array 前景色，rgb格式
     * @param array 背景色，rgb格式
     * @param bool 是否透明
     * @return mixed
     */
    public static function makeTextPng($destImg, $font, $text, $size = 20, $bgColor = null, $fgColor = null, $transparent = true)
    {
        // 文字
        if (!$text) {
            return false;
        }
        // 字体
        if (!$font) {
            return false;
        }
        // 背景色
        if (!$bgColor) {
            $bgColor = array(255, 255, 255);
        }
        // 文字色
        if (!$fgColor) {
            $fgColor = array(0, 0, 0);
        }
        // 图片
        $file = $destImg;
        // 作图参数
        $padding = 4;
        $bounds = imagettfbbox($size, 0, $font, $text);
        $width = abs($bounds[0] + $bounds[2]) + $padding*2;
        $height = abs($bounds[1] - $bounds[7]) + $padding*2;
        $offsetX = $bounds[6] + $padding;
        $offsetY = abs($bounds[7]) + $padding;
        // 作图
        $im = imagecreatetruecolor($width, $height);
        imageinterlace($im, false);
        imagesavealpha($im, true);
        // 背景
        if ($transparent) {
            $color = imagecolorallocatealpha($im, $bgColor[0], $bgColor[1], $bgColor[2], 127);
            imagefill($im, 0, 0, $color);
        } else {
            $color = imagecolorallocate($im, $bgColor[0], $bgColor[1], $bgColor[2]);
            imagefill($im, 0, 0, $color);
        }
        // 文字
        $color = imagecolorallocate($im, $fgColor[0], $fgColor[1], $fgColor[2]);
        imagettftext($im, $size, 0, $offsetX, $offsetY, $color, $font, $text);
        // 输出
        if (!$file) {
            return $im;
        }
        $result = imagepng($im, $file);
        imagedestroy($im);
        if (!$result) {
            return false;
        }
        chmod($file, 0775);
        return true;
    }

	/**
     * 加水印
     *
     * @param string 源图路径
     * @param string 水印图路径或对象
     * @param int x轴位置
     * @param int y轴位置
     * @return bool
     */
    public static function addWatermark($sourceImg, $waterImg, $x = 0, $y = 0) {
        if (!$sourceImg || !file_exists($sourceImg)) {
            return false;
        }
        if (!$waterImg) {
            return false;
        }
        // 源图片处理
        $sourceInfo = getimagesize($sourceImg);
        $sourceW = $sourceInfo[0];
        $sourceH = $sourceInfo[1];
        switch ($sourceInfo[2]) {
            case 1:
                $sourceImgRs = imagecreatefromgif($sourceImg);
                break;
            case 2:
                $sourceImgRs = imagecreatefromjpeg($sourceImg);
                break;
            case 3:
                $sourceImgRs = imagecreatefrompng($sourceImg);
                break;
            default:
                $sourceImgRs = imagecreatefromjpeg($sourceImg);
                break;
        }
        if (!$sourceImgRs) {
            return false;
        }
        // 水印图片处理
		if (is_resource($waterImg)) {
			$waterImgRs = $waterImg;
			$waterW = imagesx($waterImgRs);
			$waterH = imagesy($waterImgRs);
		} else {
			$waterInfo = getimagesize($waterImg);
			$waterW = $waterInfo[0];
			$waterH = $waterInfo[1];
			switch ($waterInfo[2]) {
				case 1:
					$waterImgRs = imagecreatefromgif($waterImg);
					break;
				case 2:
					$waterImgRs = imagecreatefromjpeg($waterImg);
					break;
				case 3:
					$waterImgRs = imagecreatefrompng($waterImg);
					break;
				default:
					$waterImgRs = imagecreatefromjpeg($waterImg);
					break;
			}
			if (!$waterImgRs) {
				return false;
			}
		}
        // 水印位置处理
        $space = 10;
        $diffW = $sourceW - $waterW;
        $diffH = $sourceH - $waterH;
        if ($diffW < $space || $diffH < $space) {
            return false;
        }
        $posX = $x < $diffW ? $x : $diffW;
        $posY = $y < $diffH ? $y : $diffH;
        // 设定图像的混色模式
        imagealphablending($sourceImgRs, true);
        // 最终生成处理
        imagecopy($sourceImgRs, $waterImgRs, $posX, $posY, 0, 0, $waterW, $waterH);
        $newImg = $sourceImg.'.tmp';
        switch ($sourceInfo[2]) {
            case 1:
                $result = imagegif($sourceImgRs, $newImg, 100);
                break;
            case 2:
                $result = imagejpeg($sourceImgRs, $newImg, 100);
                break;
            case 3:
                $result = imagepng($sourceImgRs, $newImg, 100);
                break;
            default:
                $result = imagejpeg($sourceImgRs, $newImg, 100);
                break;
        }
        imagedestroy($sourceImgRs);
        if (file_exists($newImg)) {
            if (filesize($newImg) > 1024) {
                rename($newImg, $sourceImg);
            }
            @unlink($newImg);
        }
        return $result ? true : false;
    }

    /**
     * 生成缩略图
     *
     * @param string 源图路径
     * @param string 缩略图路径，为空则返回资源对象
     * @param int 最大宽度
     * @param int 最大高度
     * @return mixed
     */
    public static function makeThumb($sourceImg, $destImg, $maxWidth, $maxHeight)
    {
        if (!$sourceImg || !file_exists($sourceImg)) {
            return false;
        }
        $sourceInfo = getimagesize($sourceImg);
        $sourceWidth = $sourceInfo[0];
        $sourceHeight = $sourceInfo[1];
        if ((!$maxWidth || $maxWidth >= $sourceWidth) || (!$maxHeight || $maxHeight >= $sourceHeight)) {
            return true;
        }
        switch ($sourceInfo[2]) {
            case 1:
                $sourceImgRs = imagecreatefromgif($sourceImg);
                break;
            case 2:
                $sourceImgRs = imagecreatefromjpeg($sourceImg);
                break;
            case 3:
                $sourceImgRs = imagecreatefrompng($sourceImg);
                break;
            default:
                $sourceImgRs = imagecreatefromjpeg($sourceImg);
                break;
        }
        if (!$sourceImgRs) {
            return false;
        }
        $ratioWidth = 1.0 * $maxWidth / $imageWidth;
        $ratioHeight = 1.0 * $maxHeight / $imageHeight;
        $ratio = max($ratioWidth, $ratioHeight);
        $destWidth = intval($sourceWidth*$ratio);
        $destHeight = intval($sourceHeight*$ratio);
        $destImgRs = imagecreatetruecolor($destWidth, $destHeight);
        imagecopyresampled($destImgRs, $sourceImgRs, 0, 0, 0, 0, $destWidth, $destHeight, $sourceWidth, $sourceHeight);
        if ($maxWidth && $maxHeight) {
            $newImgRs = imagecreatetruecolor($destWidth, $destHeight);
            imagecopyresampled($newImgRs, $destImgRs, 0, 0, 0, 0, $maxWidth, $maxHeight, $destWidth, $destHeight);
            $destImgRs = $newImgRs;
        }
        if (!$destImg) {
            return $destImgRs;
        }
        switch ($sourceInfo[2]) {
            case 1:
                $result = imagegif($destImgRs, $destImg);
                break;
            case 2:
                $result = imagejpeg($destImgRs, $destImg);
                break;
            case 3:
                imagesavealpha($destImgRs, true);
                $result = imagepng($destImgRs, $destImg);
                break;
            default:
                $result = imagejpeg($destImgRs, $destImg);
                break;
        }
        imagedestroy($destImgRs);
        return $result ? true : false;
    }

    /**
     * 圆角处理
     *
     * @param string 源图路径
     * @param string 目标图路径
     * @param string 圆角图路径
     * @param int 弧度
     * @return bool
     */
    public static function addRoundCorner($sourceImg, $destImg, $cornerImg, $radius = 10)
    {
        if (!$sourceImg || !file_exists($sourceImg)) {
            return false;
        }
        if (!$cornerImg || !file_exists($cornerImg)) {
            return false;
        }
        // 源图片处理
        $sourceInfo = getimagesize($sourceImg);
        $sourceW = $sourceInfo[0];
        $sourceH = $sourceInfo[1];
        switch ($sourceInfo[2]) {
            case 1:
                $sourceImgRs = imagecreatefromgif($sourceImg);
                break;
            case 2:
                $sourceImgRs = imagecreatefromjpeg($sourceImg);
                break;
            case 3:
                $sourceImgRs = imagecreatefrompng($sourceImg);
                break;
            default:
                $sourceImgRs = imagecreatefromjpeg($sourceImg);
                break;
        }
        if (!$sourceImgRs) {
            return false;
        }
        // 圆角图片处理
        $cornerInfo = getimagesize($cornerImg);
        $cornerW = $cornerInfo[0];
        $cornerH = $cornerInfo[1];
        switch ($cornerInfo[2]) {
            case 1:
                $cornerImgRs = imagecreatefromgif($cornerImg);
                break;
            case 2:
                $cornerImgRs = imagecreatefromjpeg($cornerImg);
                break;
            case 3:
                $cornerImgRs = imagecreatefrompng($cornerImg);
                break;
            default:
                $cornerImgRs = imagecreatefromjpeg($cornerImg);
                break;
        }
        if (!$cornerImgRs) {
            return false;
        }
        // 圆角调整
        $newCornerW = $radius;
        $newCornerH = $radius;
        $newCornerImgRs = imagecreatetruecolor($newCornerW, $newCornerH);
        imagecopyresampled($newCornerImgRs, $cornerImgRs, 0, 0, 0, 0, $newCornerW, $newCornerH, $cornerW, $cornerH);
        $white = imagecolorallocate($sourceImgRs, 255, 255, 255);
        $black = imagecolorallocate($sourceImgRs, 0, 0, 0);
        // 左上
        $x = 0;
        $y = 0;
        imagecolortransparent($newCornerImgRs, $black);
        imagecopymerge($sourceImgRs, $newCornerImgRs, $x, $y, 0, 0, $newCornerW, $newCornerH, 100);
        // 左下
        $x = 0;
        $y = $sourceH - $newCornerH;
        $rotatedCornerImgRs = imagerotate($newCornerImgRs, 90, 0);
        imagecolortransparent($rotatedCornerImgRs, $black);
        imagecopymerge($sourceImgRs, $rotatedCornerImgRs, $x, $y, 0, 0, $newCornerW, $newCornerH, 100);
        // 右下
        $x = $sourceW - $newCornerW;
        $y = $sourceH - $newCornerH;
        $rotatedCornerImgRs = imagerotate($newCornerImgRs, 180, 0);
        imagecolortransparent($rotatedCornerImgRs, $black);
        imagecopymerge($sourceImgRs, $rotatedCornerImgRs, $x, $y, 0, 0, $newCornerW, $newCornerH, 100);
        // 右上
        $x = $sourceW - $newCornerW;
        $y = 0;
        $rotatedCornerImgRs = imagerotate($newCornerImgRs, 270, 0);
        imagecolortransparent($rotatedCornerImgRs, $black);
        imagecopymerge($sourceImgRs, $rotatedCornerImgRs, $x, $y, 0, 0, $newCornerW, $newCornerH, 100);
        // 输出
        $newImg = $destImg.'.tmp';
        switch ($sourceInfo[2]) {
            case 1:
                $result = imagegif($sourceImgRs, $newImg);
                break;
            case 2:
                $result = imagejpeg($sourceImgRs, $newImg);
                break;
            case 3:
                $result = imagepng($sourceImgRs, $newImg);
                break;
            default:
                $result = imagejpeg($sourceImgRs, $newImg);
                break;
        }
        imagedestroy($sourceImgRs);
        if (file_exists($newImg)) {
            if (filesize($newImg) > 1024) {
                rename($newImg, $destImg);
            }
            @unlink($newImg);
        }
        return $result ? true : false;
   }
}
