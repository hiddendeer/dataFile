<?php
ini_set('display_errors', 'on');
error_reporting(E_ERROR);

require_once dirname(__FILE__).'/ImgTool.php';
require_once dirname(__FILE__).'/function.php';

// 背景图片序号
$bgNum = 1;
// 左侧参数
$leftData = array(
	'img' => dirname(__FILE__).'/img/avatar1.jpg',
	'txt' => array(
		'name' => '女方：天使',
		'age' => '年龄：1岁',
		'area' => '地区：崇左'
	)
);
// 右侧参数
$rightData = array(
	'img' => dirname(__FILE__).'/img/avatar2.jpg',
	'txt' => array(
		'name' => '男方：风小鱼',
		'age' => '年龄：1岁',
		'area' => '地区：南京'
	),
);
// 生成
$result = buildQMZM($bgNum, $leftData, $rightData);
if (!$result) {
	exit("生成失败");
}
$url = 'http://192.168.0.10/test/qmzm/pic/'.$result;
echo "<img src=\"{$url}\">";
?>