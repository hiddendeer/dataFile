<?php
/**
 * @abstract 图片操作
 * @final 2013.7.25
 */

class ImgTool {

	// 生成带文字图片
	public static function makeTextPng($destImg, $text, $size = 20, $bgColor = null, $fgColor = null, $font = null, $transparent = true) {
		// 文字
		if (!$text) {
			return false;
		}
		// 字体
		if (!$font) {
			$font = dirname(__FILE__).'/fonts/simsun.ttf';
		}
		// 背景色
		if (!$bgColor) {
			$bgColor = array(255, 255, 255);
		}
		// 文字色
		if (!$fgColor) {
			$fgColor = array(0, 0, 0);
		}
		// 图片
		$file = $destImg;
		// 作图参数
		$padding = 4;
		$bounds = imagettfbbox($size, 0, $font, $text);
		$width = abs($bounds[0] + $bounds[2]) + $padding*2;
		$height = abs($bounds[1] - $bounds[7]) + $padding*2;
		$offsetX = $bounds[6] + $padding;
		$offsetY = abs($bounds[7]) + $padding;
		// 作图
		$im = imagecreatetruecolor($width, $height);
		imageinterlace($im, false);
		imagesavealpha($im, true);
		// 背景
		if ($transparent) {
			$color = imagecolorallocatealpha($im, $bgColor[0], $bgColor[1], $bgColor[2], 127);
			imagefill($im, 0, 0, $color);
		} else {
			$color = imagecolorallocate($im, $bgColor[0], $bgColor[1], $bgColor[2]);
			imagefill($im, 0, 0, $color);
		}
		// 文字
		$color = imagecolorallocate($im, $fgColor[0], $fgColor[1], $fgColor[2]);
		imagettftext($im, $size, 0, $offsetX, $offsetY, $color, $font, $text);
		// 输出
		$result = imagepng($im, $file);
		imagedestroy($im);
		if (!$result) {
			return false;
		}
		chmod($file, 0775);
		return true;
	}

	// 截图
	public static function makeThumb($sourceImg, $destImg, $maxWidth, $maxHeight) {
		if (!$sourceImg || !file_exists($sourceImg)) {
			return false;
		}
		$sourceInfo = getimagesize($sourceImg);
		$sourceWidth = $sourceInfo[0];
		$sourceHeight = $sourceInfo[1];
		if ((!$maxWidth || $maxWidth >= $sourceWidth) || (!$maxHeight || $maxHeight >= $sourceHeight)) {
			return true;
		}
		switch ($sourceInfo[2]) {
			case 1:
				$sourceImgRs = imagecreatefromgif($sourceImg);
				break;
			case 2:
				$sourceImgRs = imagecreatefromjpeg($sourceImg);
				break;
			case 3:
				$sourceImgRs = imagecreatefrompng($sourceImg);
				break;
			default:
				$sourceImgRs = imagecreatefromjpeg($sourceImg);
				break;
		}
		if (!$sourceImgRs) {
			return false;
		}
		$ratioWidth = 1.0 * $maxWidth / $imageWidth;
		$ratioHeight = 1.0 * $maxHeight / $imageHeight;
		$ratio = max($ratioWidth, $ratioHeight);
		$destWidth = intval($sourceWidth*$ratio);
		$destHeight = intval($sourceHeight*$ratio);
		$destImgRs = imagecreatetruecolor($destWidth, $destHeight);
		imagecopyresampled($destImgRs, $sourceImgRs, 0, 0, 0, 0, $destWidth, $destHeight, $sourceWidth, $sourceHeight);
		if ($maxWidth && $maxHeight) {
			$newImgRs = imagecreatetruecolor($destWidth, $destHeight);
			imagecopyresampled($newImgRs, $destImgRs, 0, 0, 0, 0, $maxWidth, $maxHeight, $destWidth, $destHeight);
			$destImgRs = $newImgRs;
		}
		switch ($sourceInfo[2]) {
			case 1:
				$result = imagegif($destImgRs, $destImg);
				break;
			case 2:
				$result = imagejpeg($destImgRs, $destImg);
				break;
			case 3:
				imagesavealpha($destImgRs, true);
				$result = imagepng($destImgRs, $destImg);
				break;
			default:
				$result = imagejpeg($destImgRs, $destImg);
				break;
		}
		imagedestroy($destImgRs);
		return $result ? true : false;
	}

	// 加水印
	public static function addWatermark($sourceImg, $waterImg, $x = 0, $y = 0) {
		if (!$sourceImg || !file_exists($sourceImg)) {
			return false;
		}
		if (!$waterImg || !file_exists($waterImg)) {
			return false;
		}
		// 源图片处理
		$sourceInfo = getimagesize($sourceImg);
		$sourceW = $sourceInfo[0];
		$sourceH = $sourceInfo[1];
		switch ($sourceInfo[2]) {
			case 1:
				$sourceImgRs = imagecreatefromgif($sourceImg);
				break;
			case 2:
				$sourceImgRs = imagecreatefromjpeg($sourceImg);
				break;
			case 3:
				$sourceImgRs = imagecreatefrompng($sourceImg);
				break;
			default:
				$sourceImgRs = imagecreatefromjpeg($sourceImg);
				break;
		}
		if (!$sourceImgRs) {
			return false;
		}
		// 水印图片处理
		$waterInfo = getimagesize($waterImg);
		$waterW = $waterInfo[0];
		$waterH = $waterInfo[1];
		switch ($waterInfo[2]) {
			case 1:
				$waterImgRs = imagecreatefromgif($waterImg);
				break;
			case 2:
				$waterImgRs = imagecreatefromjpeg($waterImg);
				break;
			case 3:
				$waterImgRs = imagecreatefrompng($waterImg);
				break;
			default:
				$waterImgRs = imagecreatefromjpeg($waterImg);
				break;
		}
		if (!$waterImgRs) {
			return false;
		}
		// 水印位置处理
		$space = 10;
		$diffW = $sourceW - $waterW;
		$diffH = $sourceH - $waterH;
		if ($diffW < $space || $diffH < $space) {
			return false;
		}
		$posX = $x < $diffW ? $x : $diffW;
		$posY = $y < $diffH ? $y : $diffH;
		// 设定图像的混色模式
		imagealphablending($sourceImgRs, true);
		// 最终生成处理
		imagecopy($sourceImgRs, $waterImgRs, $posX, $posY, 0, 0, $waterW, $waterH);
		$newImg = $sourceImg.'.tmp';
		switch ($sourceInfo[2]) {
			case 1:
				$result = imagegif($sourceImgRs, $newImg);
				break;
			case 2:
				$result = imagejpeg($sourceImgRs, $newImg);
				break;
			case 3:
				$result = imagepng($sourceImgRs, $newImg);
				break;
			default:
				$result = imagejpeg($sourceImgRs, $newImg);
				break;
		}
		imagedestroy($sourceImgRs);
		if (file_exists($newImg)) {
			if (filesize($newImg) > 5120) {
				rename($newImg, $sourceImg);
			}
			@unlink($newImg);
		}
		return $result ? true : false;
	}
}
?>
