<?php
// 青梅竹马合成图
function buildQMZM($bgNum, $leftData, $rightData) {
	// 根目录
	$pathRoot = dirname(__FILE__);
	// 临时图片保存目录
	$pathTemp = $pathRoot.'/tmp';
	if (!file_exists($pathTemp) || !is_writable($pathTemp)) {
		exit('临时目录不存在或不可写');
	}
	// 生成图片保存目录
	$pathSave = $pathRoot.'/pic';
	if (!file_exists($pathSave) || !is_writable($pathSave)) {
		exit('保存目录不存在或不可写');
	}
	// 字体
	$font = array(
		0 => $pathRoot.'/font/simsun.ttf', // 宋体
		1 => $pathRoot.'/font/simsunb.ttf', // 宋体粗体
		2 => $pathRoot.'/font/simsunt.ttf', // 宋体细体
	);
	// 背景
	$bg = array(
		1 => $pathRoot.'/img/bg1.png',
		2 => $pathRoot.'/img/bg2.png'
	);
	// 配置
	switch ($bgNum) {
		case 1: // 使用背景1的配置
			$leftConfig = array(
				'img' => array('x' => 193, 'y' => 132), // 图片x轴坐标、y轴坐标
				'txt' => array(
					'name' => array('size' => 12, 'color' => array(228,88,114), 'font' => $font[1], 'x' => 50, 'y' => 130), // 文字大小、颜色、字体、x轴坐标、y轴坐标
					'age' => array('size' => 10, 'color' => array(110,107,92), 'font' => $font[0], 'x' => 50, 'y' => 153),
					'area' => array('size' => 10, 'color' => array(110,107,92), 'font' => $font[0], 'x' => 50, 'y' => 170)
				)
			);
			$rightConfig = array(
				'img' => array('x' => 319, 'y' => 132),
				'txt' => array(
					'name' => array('size' => 12, 'color' => array(60,159,156), 'font' => $font[1], 'x' => 434, 'y' => 130), // 文字大小、颜色、字体、x轴坐标、y轴坐标
					'age' => array('size' => 10, 'color' => array(110,107,92), 'font' => $font[0], 'x' => 434, 'y' => 153),
					'area' => array('size' => 10, 'color' => array(110,107,92), 'font' => $font[0], 'x' => 434, 'y' => 170)
				)
			);
			break;
		case 2: // 使用背景2的配置
			$leftConfig = array(
				'img' => array('x' => 193, 'y' => 132), // 图片x轴坐标、y轴坐标
				'txt' => array(
					'name' => array('size' => 12, 'color' => array(228,88,114), 'font' => $font[1], 'x' => 50, 'y' => 130), // 文字大小、颜色、字体、x轴坐标、y轴坐标
					'age' => array('size' => 10, 'color' => array(110,107,92), 'font' => $font[0], 'x' => 50, 'y' => 153),
					'area' => array('size' => 10, 'color' => array(110,107,92), 'font' => $font[0], 'x' => 50, 'y' => 170)
				)
			);
			$rightConfig = array(
				'img' => array('x' => 319, 'y' => 132),
				'txt' => array(
					'name' => array('size' => 12, 'color' => array(60,159,156), 'font' => $font[1], 'x' => 434, 'y' => 130), // 文字大小、颜色、字体、x轴坐标、y轴坐标
					'age' => array('size' => 10, 'color' => array(110,107,92), 'font' => $font[0], 'x' => 434, 'y' => 153),
					'area' => array('size' => 10, 'color' => array(110,107,92), 'font' => $font[0], 'x' => 434, 'y' => 170)
				)
			);
			break;
		default:
			return false;
			break;
	}
	// 背景图片
	$bgImg = $bg[$bgNum];
	// 目标图片
	$ext = pathinfo($bgImg, PATHINFO_EXTENSION);
	$newName = md5(microtime(true)).'.'.$ext;
	$newImg = $pathSave.'/'.$newName;
	if (file_exists($newImg)) {
		return buildQMZM($bgNum, $leftData, $rightData);
	}
	copy($bgImg, $newImg);
	// 加左侧头像
	$img = $leftData['img'];
	$cofnig = $leftConfig['img'];
	ImgTool::addWatermark($newImg, $img, $cofnig['x'], $cofnig['y']);
	// 加右侧头像
	$img = $rightData['img'];
	$cofnig = $rightConfig['img'];
	ImgTool::addWatermark($newImg, $img, $cofnig['x'], $cofnig['y']);
	// 加左侧文字
	if ($leftData['txt']) {
		foreach ($leftData['txt'] as $k => $v) {
			$txt = $v;
			$config = $leftConfig['txt'][$k];
			if (!$v || !$config) {
				continue;
			}
			$img = $pathTemp.'/'.md5(microtime(true)).'.png';
			ImgTool::makeTextPng($img, $txt, $config['size'], null, $config['color'], $config['font'], true);
			ImgTool::addWatermark($newImg, $img, $config['x'], $config['y']);
		}
	}
	// 加右侧文字
	if ($rightData['txt']) {
		foreach ($rightData['txt'] as $k => $v) {
			$txt = $v;
			$config = $rightConfig['txt'][$k];
			if (!$v || !$config) {
				continue;
			}
			$img = $pathTemp.'/'.md5(microtime(true)).'.png';
			ImgTool::makeTextPng($img, $txt, $config['size'], null, $config['color'], $config['font'], true);
			ImgTool::addWatermark($newImg, $img, $config['x'], $config['y']);
		}
	}
	// 返回生成图片的名称
	return $newName;
}
?>