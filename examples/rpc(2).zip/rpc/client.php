<?php
/**
 * rpc客户端
 *
 * @author sc-edu
 * @version 2.0
 * @date 2018/03/12
 */

require_once __DIR__.'/lib/class_xmlrpc.php';

// 调取函数1 参数依次为：服务器端的地址 命名空间
$var1 = 'abc';
$var2 = 'www';
$xmlrpc_client = new xmlrpc_client('http://localhost/yourpath/rpc/server.php', 'namespace1');// 
$result = $xmlrpc_client->call('func1', $var1, $var2);// 这里传递过去的参数，除了第一个是函数名字外，其他都会被封装为一个数组，保存在服务器端的$param变量中
print_r($result);
exit;

// 调取函数2 参数依次为：服务器端的地址 命名空间
$var1 = 23241;
$var2 = 97658;
$xmlrpc_client = new xmlrpc_client('http://localhost/yourpath/rpc/server.php', 'namespace1');// 
$result = $xmlrpc_client->call('add', $var1, $var2);// 这里传递过去的参数，除了第一个是函数名字外，其他都会被封装为一个数组，保存在服务器端的$param变量中
print_r($result);
exit;

// 调取函数3 参数依次为：服务器端的地址 命名空间
$type = 1;
$arr = array(
	'mobile' => '13689785698',
	'email' => 'test@163.com.cn',
	'qq' => '88888888',
);
$xmlrpc_client = new xmlrpc_client('http://localhost/yourpath/rpc/server.php', 'namespace1');// 
$result = $xmlrpc_client->call('process', $type, $arr);// 这里传递过去的参数，除了第一个是函数名字外，其他都会被封装为一个数组，保存在服务器端的$param变量中
print_r($result);
exit;
