<?php
/**
 * rpc测试
 *
 * @author sc-edu
 * @version 2.0
 * @date 2018/03/12
 */

require_once __DIR__.'/lib/class_xmlrpc.php';

ini_set('display_errors','on');
error_reporting(7);

header("Content-type:text/html;charset=utf-8");


// 给指定微信帐号发送消息通知，需要关注对应公众号，比如sc对应赛诚智慧
$conf = 'sc';//微信公众号标识码：aibeier baice jim jwb sc_jwb sc
$data = array(
	'open_id' => 'oU9xxxxxxxxxxxxxxxxxxxxxxx',//对应公众号下用户的openid，在微信中访问http://m.yunyuer.com/uc/my_weixin1118.php即可获取自身open_id等信息
	'tmpl_id' => '_ZxSiFn1O3zGWfLmYZAdM4Tep9B2WpO49YvNUFzyo64',//公众号下的消息模版id
	'tmpl_data' => array(//模版参数
		'first' => array(
			'value' => '标题部分的内容\n',//标题部分的内容，支持\n换行
			'color' => '#173177',//可自定义颜色
		),
		'keyword1' => array(//键值可能是keyword也可能使keynote，自己根据模版参数调整
			'value' => '第一个关键词的内容',//关键词1的内容，根据模版含有关键词的数量动态调整这里的数量
			'color' => '#173177',//可自定义颜色
		),
		'keyword2' => array(//键值可能是keyword也可能使keynote，自己根据模版参数调整
			'value' => '第二个关键词的内容',
			'color' => '#173177',
		),
		'keyword3' => array(//键值可能是keyword也可能使keynote，自己根据模版参数调整
			'value' => '第三个关键词的内容',
			'color' => '#173177',
		),
		'remark' => array(
			'value' => '\n模板消息最后一行的内容',//最后一行的内容，支持\n换行
			'color' => '#173177',
		),
	),
	'url' => 'http://wx.yunyuer.com/weiweb/ab/',//网页跳转链接，可选，若网页和小程序都传，会优先跳转至小程序
	'mini_url' => array(//小程序跳转参数，可选
//		'appid' => 'xiaochengxuappid12345',//所需跳转到的小程序appid（该小程序appid必须与发模板消息的公众号是绑定关联关系）
//		'pagepath' => 'index?foo=bar',//所需跳转到小程序的具体页面路径，支持带参数
	),
);
$xmlrpc_client = new xmlrpc_client('https://api.sc-edu.com/mp/rpc/tmessService.php', 'mp');
$result = $xmlrpc_client->call('send', $conf, $data);
print_r($result);//返回数组，其中键值state=0表示成功，成功返回的编号在data键值中，示例如下
exit;
/*
Array
(
    [state] => 0
    [message] => 
    [data] => Array
        (
			[tmess_id] => 19 //记录id
            [msgid] => 459202138 //微信端返回的id
        )

)
*/


// 给指定手机号发送短信 注意频率，同一个号码每分钟只能发一次，每天不超过5次，否则会被拉入黑名单
$mobile = '138xxxxxxxx';//手机号
$tmpl_id = 43;//短信模版id，例如43对应模版为 尊敬的用户，您的短信验证码为{data[0]}，如非本人操作，请忽略。
$tmpl_data = array(//模版参数，参数按照模版中变量的顺序对应好
	mt_rand(1111,9999),
);
$xmlrpc_client = new xmlrpc_client('http://m.ci123.com/sms/rpc/smsService.php', 'sms.template');
$result = $xmlrpc_client->call('sendByTemplate', $mobile, $tmpl_id, $tmpl_data);
print_r($result);//返回数组，其中键值state=0表示成功，成功返回的编号在data键值中
exit;
/*
Array
(
    [state] => 0
    [message] => 
    [data] => Array
        (
            [pid] => 2315208543768594430 //服务商返回的消息批次id
            [log_id] => 2374181 //日志id
        )

)
