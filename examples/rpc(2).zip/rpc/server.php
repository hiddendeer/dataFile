<?php
/**
 * rpc服务端
 *
 * @author sc-edu
 * @version 2.0
 * @date 2018/03/12
 */

require_once __DIR__.'/lib/class_xmlrpc.php';

/**
 * 示例函数1 函数名自定义，客户端根据名称调用
 *
 * @param string var1
 * @param string var2
 * @return string
 */
function func1($method, $param) {
	// 客户端传递过来的参数，会封装到$param变量中，前面的$method默认即可，一般用不到
	$var1 = trim($param[0]);
	$var2 = trim($param[1]);
	return 'var1 is '.$var1.' and var2 is '.$var2;
}

/**
 * 示例函数2
 *
 * @param int var1
 * @param int var2
 * @return int
 */
function add($method, $param){
	// 客户端传递过来的参数，会封装到$param变量中，前面的$method默认即可，一般用不到
	$var1 = intval($param[0]);
	$var2 = intval($param[1]);
	return $var1 + $var2;
}

/**
 * 示例函数3
 *
 * @param int type
 * @param array arr
 * @return int
 */
function process($method, $param){
	// 客户端传递过来的参数，会封装到$param变量中，前面的$method默认即可，一般用不到
	$type = intval($param[0]);
	$arr = $param[1];
	if ($type == 1) {
		$arr['mobile'] = str_replace('136', '138', $arr['mobile']);
		$arr['email'] = str_replace('.com.cn', '.com', $arr['email']);
	} else {
		$arr['mobile'] = '+86'.$arr['mobile'];
	}
	return $arr;
}

// 命名空间，自定义，客户端调取函数时需要正确传递这个命名空间
$xmlrpc_name = 'namespace1';
// 封装 注意函数的命名
$xmlrpc_funcs = array(
	'func1',
	'add',
	'process'
);
$xmlrpc_server = new xmlrpc_server();
foreach ($xmlrpc_funcs as $v) {
	$xmlrpc_server->register_method($xmlrpc_name.'.'.$v, $v);
}
$xmlrpc_server->call_method();